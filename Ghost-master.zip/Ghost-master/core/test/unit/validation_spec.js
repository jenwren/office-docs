var should  = require('should'),

    validation = require('../../server/data/validation');

// Validate our customisations
describe('Validation', function () {
    it('should export our required functions', function () {
        should.exist(validation);

        validation.should.have.properties(
            ['validate', 'validator', 'validateSchema', 'validateSettings', 'validateActiveTheme']
        );

        validation.validate.should.be.a.Function();
        validation.validateSchema.should.be.a.Function();
        validation.validateSettings.should.be.a.Function();
        validation.validateActiveTheme.should.be.a.Function();

        validation.validator.should.have.properties(['empty', 'notContains', 'isTimezone', 'isEmptyOrURL', 'isSlug']);
    });

    describe('Validator customisations', function () {
        var validator = validation.validator;

        it('isEmptyOrUrl filters javascript urls', function () {
            /*jshint scripturl:true */
            validator.isEmptyOrURL('javascript:alert(0)').should.be.false();
            /*jshint scripturl:false */
            validator.isEmptyOrURL('').should.be.true();
            validator.isEmptyOrURL('http://localhost:2368').should.be.true();
        });
    });
});
