export var foo = () => new RegExp('');
