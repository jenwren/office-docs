{
	this.foo = 9;
}