class A2 {
	public count: number = 9;
	public resolveNextGeneration(cell : A2) {
	}
}