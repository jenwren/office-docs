function foo3() {
	const foo = (): any => ({ 'bar': 'baz' })
}