let a = Array<number>();   // Highlight ok here

interface egGenericsInArray {
   a: Array<number>;
}
let s = "nothing should fail here...";