/*---------------------------------------------------------------------------------------------
 *  Copyright (c) Microsoft Corporation. All rights reserved.
 *  Licensed under the MIT License. See License.txt in the project root for license information.
 *--------------------------------------------------------------------------------------------*/

/// <reference path='../../../../src/vs/vscode.d.ts'/>
/// <reference path='../../../declares.d.ts'/>
/// <reference path='../../../lib.core.d.ts'/>
/// <reference path='../../../node.d.ts'/>
