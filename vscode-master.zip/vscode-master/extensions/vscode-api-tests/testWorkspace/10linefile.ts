function foo(): void {
    var a = 1;
    a = 1;
    a = 1;
    a = 1;
    a = 1;
    a = 1;
    a = 1;
    a = 1;
}